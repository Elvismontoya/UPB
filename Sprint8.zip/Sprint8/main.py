import logging
from registro import registrar_mascota, registrar_consulta, listar_mascotas
from historial import ver_historial
from persistencia import guardar_mascotas_y_duenos_csv, cargar_mascotas_y_duenos_csv, guardar_consultas_json, cargar_consultas_json
from mascota import Mascota
from dueno import Dueno

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("clinica_veterinaria.log"),
        logging.StreamHandler()
    ]
)

# Cargar datos al iniciar
lista_mascotas, lista_duenos = cargar_mascotas_y_duenos_csv()
lista_consultas = cargar_consultas_json(lista_mascotas)

def importar_mascotas_por_defecto():
    if not lista_mascotas:
        print("No se encontraron mascotas. Importando mascotas por defecto...")
        dueno1 = Dueno("Carlos Pérez", "3001234567", "Cra 1 #10-20", "12345678")
        dueno2 = Dueno("Ana Gómez", "3017654321", "Calle 5 #22-30", "87654321")

        mascota1 = Mascota("Firulais", "Perro", "Labrador", 5, dueno1)
        mascota2 = Mascota("Misu", "Gato", "Persa", 3, dueno2)

        lista_duenos.extend([dueno1, dueno2])
        lista_mascotas.extend([mascota1, mascota2])

        guardar_mascotas_y_duenos_csv(lista_mascotas, lista_duenos)
        print("Mascotas por defecto importadas:")
        for m in lista_mascotas:
            print(f"- {m.nombre} ({m.especie}) del dueño {m.dueno.nombre}")

def actualizar_mascota():
    if not lista_mascotas:
        print("No hay mascotas registradas.")
        return
    
    print("\n--- Actualizar Mascota ---")
    listar_mascotas(lista_mascotas)
    
    try:
        seleccion = int(input("\nSeleccione el número de mascota a actualizar: ")) - 1
        if seleccion < 0 or seleccion >= len(lista_mascotas):
            print("Número inválido.")
            return
            
        mascota = lista_mascotas[seleccion]
        
        print("\nDeje en blanco los campos que no desea cambiar")
        nuevo_nombre = input(f"Nombre actual ({mascota.nombre}): ") or mascota.nombre
        nueva_especie = input(f"Especie actual ({mascota.especie}): ") or mascota.especie
        nueva_raza = input(f"Raza actual ({mascota.raza}): ") or mascota.raza
        nueva_edad = input(f"Edad actual ({mascota.edad}): ")
        nueva_edad = int(nueva_edad) if nueva_edad else mascota.edad
        
        mascota.nombre = nuevo_nombre
        mascota.especie = nueva_especie
        mascota.raza = nueva_raza
        mascota.edad = nueva_edad
        
        print("\n¿Desea actualizar los datos del dueño?")
        print(f"Dueño actual: {mascota.dueno.nombre} (RUT: {mascota.dueno.rut})")
        actualizar_dueno = input("¿Actualizar dueño? (s/n): ").lower()
        
        if actualizar_dueno == 's':
            dueno = mascota.dueno
            print("\nDeje en blanco los campos que no desea cambiar")
            nuevo_nombre = input(f"Nombre actual ({dueno.nombre}): ") or dueno.nombre
            nuevo_telefono = input(f"Teléfono actual ({dueno.telefono}): ") or dueno.telefono
            nueva_direccion = input(f"Dirección actual ({dueno.direccion}): ") or dueno.direccion
            
            dueno.nombre = nuevo_nombre
            dueno.telefono = nuevo_telefono
            dueno.direccion = nueva_direccion
        
        guardar_mascotas_y_duenos_csv(lista_mascotas, lista_duenos)
        print("¡Mascota actualizada exitosamente!")
        
    except ValueError:
        print("Entrada inválida. Por favor ingrese un número.")

def eliminar_mascota():
    if not lista_mascotas:
        print("No hay mascotas registradas.")
        return
    
    print("\n--- Eliminar Mascota ---")
    listar_mascotas(lista_mascotas)
    
    try:
        seleccion = int(input("\nSeleccione el número de mascota a eliminar: ")) - 1
        if seleccion < 0 or seleccion >= len(lista_mascotas):
            print("Número inválido.")
            return
            
        mascota = lista_mascotas.pop(seleccion)
        print(f"\nMascota '{mascota.nombre}' eliminada exitosamente.")
        
        # Verificar si el dueño tiene otras mascotas
        tiene_otras_mascotas = any(m for m in lista_mascotas if m.dueno.rut == mascota.dueno.rut)
        if not tiene_otras_mascotas:
            lista_duenos.remove(mascota.dueno)
            print(f"Dueño '{mascota.dueno.nombre}' también eliminado por no tener más mascotas.")
        
        guardar_mascotas_y_duenos_csv(lista_mascotas, lista_duenos)
        
    except ValueError:
        print("Entrada inválida. Por favor ingrese un número.")

def menu():
    importar_mascotas_por_defecto()
    
    while True:
        print("\n🐾 Clínica Veterinaria 'Amigos Peludos'")
        print("1. Registrar Mascota")
        print("2. Actualizar Mascota")
        print("3. Eliminar Mascota")
        print("4. Listar Mascotas")
        print("5. Registrar Consulta")
        print("6. Ver Historial de Consultas")
        print("7. Exportar Información")
        print("8. Importar Información")
        print("9. Salir")

        opcion = input("\nSeleccione una opción: ")

        if opcion == "1":
            registrar_mascota(lista_mascotas, lista_duenos)
        elif opcion == "2":
            actualizar_mascota()
        elif opcion == "3":
            eliminar_mascota()
        elif opcion == "4":
            listar_mascotas(lista_mascotas)
        elif opcion == "5":
            registrar_consulta(lista_consultas, lista_mascotas)
        elif opcion == "6":
            ver_historial(lista_consultas, lista_mascotas)
        elif opcion == "7":
            guardar_mascotas_y_duenos_csv(lista_mascotas, lista_duenos)
            guardar_consultas_json(lista_consultas)
            print("\nInformación exportada exitosamente.")
        elif opcion == "8":
            lista_mascotas[:], lista_duenos[:] = cargar_mascotas_y_duenos_csv()
            lista_consultas[:] = cargar_consultas_json(lista_mascotas)
            print("\nInformación importada exitosamente.")
        elif opcion == "9":
            guardar_mascotas_y_duenos_csv(lista_mascotas, lista_duenos)
            guardar_consultas_json(lista_consultas)
            print("\n¡Gracias por usar nuestro sistema! ¡Hasta luego! 🐶🐱")
            break
        else:
            print("\nOpción no válida. Por favor seleccione una opción del 1 al 9.")

if __name__ == "__main__":
    menu()