import sqlite3
import logging
from dueno import Dueno
from mascota import Mascota
from consulta import Consulta

logger = logging.getLogger("persistencia")

DB_PATH = "clinica_veterinaria.db"

def conectar():
    return sqlite3.connect(DB_PATH)

# ---------- FUNCIONES INSERTAR ----------

def insertar_dueno_sqlite(dueno):
    try:
        with conectar() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR IGNORE INTO duenos (nombre, telefono, direccion, rut)
                VALUES (?, ?, ?, ?)
            """, (dueno.nombre, dueno.telefono, dueno.direccion, dueno.rut))
            conn.commit()
            logger.info("Dueño insertado: %s", dueno.rut)
    except Exception as e:
        logger.error("Error insertando dueño: %s", e)

def insertar_mascota_sqlite(mascota):
    try:
        with conectar() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM duenos WHERE rut = ?", (mascota.dueno.rut,))
            dueno_id = cursor.fetchone()
            if dueno_id:
                cursor.execute("""
                    INSERT INTO mascotas (nombre, especie, raza, edad, id_dueno)
                    VALUES (?, ?, ?, ?, ?)
                """, (mascota.nombre, mascota.especie, mascota.raza, mascota.edad, dueno_id[0]))
                conn.commit()
                logger.info("Mascota insertada: %s", mascota.nombre)
            else:
                logger.warning("Dueño no encontrado para la mascota: %s", mascota.nombre)
    except Exception as e:
        logger.error("Error insertando mascota: %s", e)

def insertar_consulta_sqlite(consulta):
    try:
        with conectar() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM mascotas WHERE nombre = ?", (consulta.mascota.nombre,))
            mascota_id = cursor.fetchone()
            if mascota_id:
                cursor.execute("""
                    INSERT INTO consultas (fecha, motivo, diagnostico, id_mascota)
                    VALUES (?, ?, ?, ?)
                """, (consulta.fecha, consulta.motivo, consulta.diagnostico, mascota_id[0]))
                conn.commit()
                logger.info("Consulta insertada para: %s", consulta.mascota.nombre)
            else:
                logger.warning("Mascota no encontrada para consulta")
    except Exception as e:
        logger.error("Error insertando consulta: %s", e)

# ---------- FUNCIONES CONSULTAR ----------

def obtener_duenos_sqlite():
    with conectar() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT nombre, telefono, direccion, rut FROM duenos")
        return [Dueno(*row) for row in cursor.fetchall()]

def obtener_mascotas_sqlite():
    with conectar() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT m.nombre, m.especie, m.raza, m.edad, d.nombre, d.telefono, d.direccion, d.rut
            FROM mascotas m
            JOIN duenos d ON m.id_dueno = d.id
        """)
        return [Mascota(row[0], row[1], row[2], row[3], Dueno(row[4], row[5], row[6], row[7])) for row in cursor.fetchall()]

def obtener_consultas_sqlite():
    with conectar() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT c.fecha, c.motivo, c.diagnostico, m.nombre
            FROM consultas c
            JOIN mascotas m ON c.id_mascota = m.id
        """)
        return [Consulta(row[0], row[1], row[2], Mascota(row[3], "", "", 0, None)) for row in cursor.fetchall()]

# ---------- FUNCIONES ELIMINAR ----------

def eliminar_mascota_sqlite(nombre):
    with conectar() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM mascotas WHERE nombre = ?", (nombre,))
        conn.commit()
        logger.info("Mascota eliminada: %s", nombre)

# ---------- FUNCIONES ACTUALIZAR ----------

def actualizar_edad_mascota_sqlite(nombre, nueva_edad):
    with conectar() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE mascotas SET edad = ? WHERE nombre = ?", (nueva_edad, nombre))
        conn.commit()
        logger.info("Edad actualizada para mascota: %s", nombre)
