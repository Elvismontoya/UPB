import unittest
from mascota import Mascota
from utilidades import buscar_mascota

class TestUtilidades(unittest.TestCase):

    def setUp(self):
        # Creamos una mascota de ejemplo para cada prueba
        self.mascota = Mascota("Firulais", "Perro", "Labrador", 5, "1-9")

    def test_buscar_mascota_found(self):
        lista = [self.mascota]
        resultado = buscar_mascota("Firulais", lista)
        self.assertIsNotNone(resultado)
        self.assertEqual(resultado.nombre, "Firulais")

    def test_buscar_mascota_not_found(self):
        lista = []
        resultado = buscar_mascota("NoExiste", lista)
        self.assertIsNone(resultado)

if __name__ == '__main__':
    unittest.main(verbosity=2)
